import "dotenv/config";
import bcrypt from "bcryptjs";
import { pool } from "./db.js";

const name = process.env.ADMIN_NAME;
const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD;

if (!name || !email || !password || password.length < 12) {
  console.error("Set ADMIN_NAME, ADMIN_EMAIL and an ADMIN_PASSWORD of at least 12 characters in .env.");
  process.exit(1);
}

try {
  const [existing] = await pool.execute("SELECT id FROM admins WHERE email = ?", [email]);
  if (existing.length) {
    console.log("Admin already exists:", email);
  } else {
    const hash = await bcrypt.hash(password, 12);
    await pool.execute(
      "INSERT INTO admins (full_name, email, password_hash) VALUES (?, ?, ?)",
      [name, email, hash]
    );
    console.log("Admin created:", email);
  }
} catch (error) {
  console.error("Could not create admin:", error.message);
  process.exitCode = 1;
} finally {
  await pool.end();
}
